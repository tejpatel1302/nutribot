export const SERVICES = {
  PATH: "services",
  GALLERY: "gallery",
  CONTENT: "textWithIllustration",
  HERO: "hero",
};
